import { useState } from "react";
import { AlertTriangle, MapPin, Phone, Star, Accessibility, Eye, Ear, Heart, Plus, Volume2, Navigation as NavigationIcon, MessageSquare } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import NavigationBar from "@/components/Navigation";
import heatmapImage from "@/assets/heatmap-visual.jpg";

const AccessibilityPlus = () => {
  const [sosTriggered, setSosTriggered] = useState(false);
  const [buildingRatings, setBuildingRatings] = useState([
    {
      name: "Central Library",
      rating: 4.8,
      accessibility: ["Wheelchair", "Audio Guide", "Braille Signs"],
      address: "123 Main St",
      issues: []
    },
    {
      name: "Student Center",
      rating: 4.2,
      accessibility: ["Wheelchair", "Elevator", "Accessible Parking"],
      address: "456 Campus Ave",
      issues: ["No audio announcements"]
    },
    {
      name: "Old Academic Building",
      rating: 2.1,
      accessibility: ["Limited Access"],
      address: "789 College Rd",
      issues: ["No elevator", "Narrow doorways", "Poor lighting"]
    }
  ]);
  const [newRating, setNewRating] = useState({
    name: "",
    rating: "",
    accessibility: "",
    address: "",
    issues: ""
  });
  const { toast } = useToast();

  const playAlarmBeep = () => {
    // Create audio context for beep sound
    const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
    const oscillator = audioContext.createOscillator();
    const gainNode = audioContext.createGain();
    
    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);
    
    oscillator.frequency.value = 800; // High frequency beep
    gainNode.gain.value = 0.3;
    
    oscillator.start();
    oscillator.stop(audioContext.currentTime + 0.2);
    
    // Repeat beep 3 times
    setTimeout(() => {
      const oscillator2 = audioContext.createOscillator();
      const gainNode2 = audioContext.createGain();
      oscillator2.connect(gainNode2);
      gainNode2.connect(audioContext.destination);
      oscillator2.frequency.value = 800;
      gainNode2.gain.value = 0.3;
      oscillator2.start();
      oscillator2.stop(audioContext.currentTime + 0.2);
    }, 300);
    
    setTimeout(() => {
      const oscillator3 = audioContext.createOscillator();
      const gainNode3 = audioContext.createGain();
      oscillator3.connect(gainNode3);
      gainNode3.connect(audioContext.destination);
      oscillator3.frequency.value = 800;
      gainNode3.gain.value = 0.3;
      oscillator3.start();
      oscillator3.stop(audioContext.currentTime + 0.2);
    }, 600);
  };

  const handleSOS = () => {
    setSosTriggered(true);
    playAlarmBeep();
    toast({
      title: "Emergency Alert Sent!",
      description: "Emergency services have been notified with your accessibility profile.",
    });
    // Simulate emergency response
    setTimeout(() => setSosTriggered(false), 3000);
  };

  const handleAddRating = () => {
    if (!newRating.name || !newRating.rating || !newRating.address) {
      toast({
        title: "Missing Information",
        description: "Please fill in building name, rating, and address.",
        variant: "destructive",
      });
      return;
    }

    const rating = {
      name: newRating.name,
      rating: parseFloat(newRating.rating),
      accessibility: newRating.accessibility.split(',').map(item => item.trim()).filter(item => item),
      address: newRating.address,
      issues: newRating.issues.split(',').map(item => item.trim()).filter(item => item)
    };

    setBuildingRatings([...buildingRatings, rating]);
    setNewRating({ name: "", rating: "", accessibility: "", address: "", issues: "" });
    toast({
      title: "Rating Added!",
      description: `Successfully added rating for ${rating.name}.`,
    });
  };

  const handleMobilitySupport = () => {
    toast({
      title: "Mobility Support Activated",
      description: "Finding wheelchair accessible routes and nearby elevators.",
    });
  };

  const handleVisualAssistance = () => {
    toast({
      title: "Visual Assistance Activated", 
      description: "Enabling audio descriptions and high-contrast mode.",
    });
  };

  const handleHearingSupport = () => {
    toast({
      title: "Hearing Support Activated",
      description: "Activating visual alerts and vibration notifications.",
    });
  };

  return (
    <div className="min-h-screen bg-background">
      <NavigationBar />
      
      <div className="max-w-7xl mx-auto p-6 space-y-8">
        {/* Header */}
        <div className="text-center space-y-4">
          <div className="flex justify-center">
            <div className="bg-gradient-primary p-4 rounded-2xl">
              <Accessibility className="h-12 w-12 text-primary-foreground" />
            </div>
          </div>
          <h1 className="text-4xl font-bold text-foreground">Accessibility+</h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Navigate safely with accessibility insights and emergency support tailored for people with disabilities
          </p>
        </div>

        {/* Emergency SOS Section */}
        <Card className={`shadow-strong ${sosTriggered ? 'bg-emergency/10 border-emergency' : ''}`}>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-emergency">
              <AlertTriangle className="h-6 w-6" />
              Emergency SOS System
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {sosTriggered ? (
              <div className="text-center space-y-4 animate-slide-up">
                <div className="text-2xl font-bold text-emergency">🚨 Emergency Alert Sent!</div>
                <p className="text-lg">Emergency services and trusted contacts have been notified of your location and accessibility needs.</p>
                <div className="bg-success/10 border border-success rounded-lg p-4">
                  <p className="text-success font-medium">✓ Location shared with responders</p>
                  <p className="text-success font-medium">✓ Accessibility profile transmitted</p>
                  <p className="text-success font-medium">✓ Emergency contacts alerted</p>
                </div>
              </div>
            ) : (
              <div className="text-center space-y-4">
                <p className="text-muted-foreground">
                  One-tap emergency assistance with automatic accessibility profile sharing
                </p>
                <Button
                  variant="sos"
                  size="xl"
                  onClick={handleSOS}
                  className="w-full max-w-md mx-auto"
                >
                  <Phone className="h-6 w-6" />
                  EMERGENCY SOS
                </Button>
                <p className="text-sm text-muted-foreground">
                  Includes location, accessibility needs, and medical information
                </p>
              </div>
            )}
          </CardContent>
        </Card>

        <div className="grid md:grid-cols-2 gap-8">
          {/* Unsafe Zones Heatmap */}
          <Card className="shadow-medium">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MapPin className="h-5 w-5 text-primary" />
                Accessibility Heatmap
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Dialog>
                <DialogTrigger asChild>
                  <div className="relative cursor-pointer hover:opacity-80 transition-opacity">
                    <img 
                      src={heatmapImage} 
                      alt="Accessibility heatmap showing safe and unsafe zones"
                      className="w-full h-64 object-cover rounded-lg"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent rounded-lg" />
                    <div className="absolute bottom-4 left-4 text-white">
                      <h3 className="font-bold">Live Accessibility Data</h3>
                      <p className="text-sm opacity-90">Click to view detailed heatmap</p>
                    </div>
                  </div>
                </DialogTrigger>
                <DialogContent className="max-w-4xl">
                  <DialogHeader>
                    <DialogTitle>Detailed Accessibility Heatmap</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4">
                    <img 
                      src={heatmapImage} 
                      alt="Detailed accessibility heatmap"
                      className="w-full h-96 object-cover rounded-lg"
                    />
                    <div className="grid grid-cols-3 gap-4 text-sm">
                      <div className="flex items-center gap-2">
                        <div className="w-4 h-4 bg-success rounded-full"></div>
                        <span>Fully Accessible Areas</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-4 h-4 bg-warning rounded-full"></div>
                        <span>Limited Access Areas</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-4 h-4 bg-emergency rounded-full"></div>
                        <span>Inaccessible Areas</span>
                      </div>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
              <div className="flex justify-between text-sm">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-success rounded-full"></div>
                  <span>Fully Accessible</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-warning rounded-full"></div>
                  <span>Limited Access</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-emergency rounded-full"></div>
                  <span>Inaccessible</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Building Ratings */}
          <Card className="shadow-medium">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Star className="h-5 w-5 text-primary" />
                  Building Accessibility Ratings
                </div>
                <Dialog>
                  <DialogTrigger asChild>
                    <Button variant="outline" size="sm">
                      <Plus className="h-4 w-4 mr-2" />
                      Add Rating
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Add Building Rating</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="name">Building Name</Label>
                        <Input 
                          id="name"
                          value={newRating.name}
                          onChange={(e) => setNewRating({...newRating, name: e.target.value})}
                          placeholder="Enter building name"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="address">Address</Label>
                        <Input 
                          id="address"
                          value={newRating.address}
                          onChange={(e) => setNewRating({...newRating, address: e.target.value})}
                          placeholder="Enter building address"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="rating">Rating (1-5)</Label>
                        <Input 
                          id="rating"
                          type="number"
                          min="1"
                          max="5"
                          step="0.1"
                          value={newRating.rating}
                          onChange={(e) => setNewRating({...newRating, rating: e.target.value})}
                          placeholder="4.5"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="accessibility">Accessibility Features (comma separated)</Label>
                        <Input 
                          id="accessibility"
                          value={newRating.accessibility}
                          onChange={(e) => setNewRating({...newRating, accessibility: e.target.value})}
                          placeholder="Wheelchair, Elevator, Braille Signs"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="issues">Known Issues (comma separated, optional)</Label>
                        <Textarea 
                          id="issues"
                          value={newRating.issues}
                          onChange={(e) => setNewRating({...newRating, issues: e.target.value})}
                          placeholder="No elevator, Poor lighting"
                        />
                      </div>
                      <Button onClick={handleAddRating} className="w-full">
                        Add Rating
                      </Button>
                    </div>
                  </DialogContent>
                </Dialog>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {buildingRatings.map((building, index) => (
                <div key={index} className="border border-border rounded-lg p-4 space-y-3">
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="font-semibold text-foreground">{building.name}</h3>
                      <p className="text-sm text-muted-foreground">{building.address}</p>
                    </div>
                    <div className="flex items-center gap-1">
                      <Star className="h-4 w-4 fill-warning text-warning" />
                      <span className="font-bold">{building.rating}</span>
                    </div>
                  </div>
                  
                  <div className="flex flex-wrap gap-1">
                    {building.accessibility.map((feature, i) => (
                      <Badge key={i} variant="secondary" className="text-xs">
                        {feature}
                      </Badge>
                    ))}
                  </div>
                  
                  {building.issues.length > 0 && (
                    <div className="space-y-1">
                      <p className="text-sm font-medium text-warning">Issues reported:</p>
                      {building.issues.map((issue, i) => (
                        <p key={i} className="text-xs text-muted-foreground">• {issue}</p>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </CardContent>
          </Card>
        </div>

        {/* Accessibility Features */}
        <div className="grid md:grid-cols-3 gap-6">
          <Card className="shadow-soft hover:shadow-medium transition-shadow cursor-pointer" onClick={handleMobilitySupport}>
            <CardContent className="p-6 text-center space-y-4">
              <div className="bg-gradient-primary p-4 rounded-full w-16 h-16 mx-auto flex items-center justify-center">
                <Accessibility className="h-8 w-8 text-primary-foreground" />
              </div>
              <h3 className="font-bold text-lg">Mobility Support</h3>
              <p className="text-muted-foreground mb-4">
                Wheelchair accessibility, ramps, elevators, and navigation assistance
              </p>
              <Button variant="outline" size="sm">
                <NavigationIcon className="h-4 w-4 mr-2" />
                Activate
              </Button>
            </CardContent>
          </Card>

          <Card className="shadow-soft hover:shadow-medium transition-shadow cursor-pointer" onClick={handleVisualAssistance}>
            <CardContent className="p-6 text-center space-y-4">
              <div className="bg-gradient-safety p-4 rounded-full w-16 h-16 mx-auto flex items-center justify-center">
                <Eye className="h-8 w-8 text-success-foreground" />
              </div>
              <h3 className="font-bold text-lg">Visual Assistance</h3>
              <p className="text-muted-foreground mb-4">
                Audio descriptions, braille signage, and high-contrast displays
              </p>
              <Button variant="outline" size="sm">
                <Volume2 className="h-4 w-4 mr-2" />
                Activate
              </Button>
            </CardContent>
          </Card>

          <Card className="shadow-soft hover:shadow-medium transition-shadow cursor-pointer" onClick={handleHearingSupport}>
            <CardContent className="p-6 text-center space-y-4">
              <div className="bg-accent p-4 rounded-full w-16 h-16 mx-auto flex items-center justify-center">
                <Ear className="h-8 w-8 text-accent-foreground" />
              </div>
              <h3 className="font-bold text-lg">Hearing Support</h3>
              <p className="text-muted-foreground mb-4">
                Sign language interpretation, visual alerts, and hearing loops
              </p>
              <Button variant="outline" size="sm">
                <MessageSquare className="h-4 w-4 mr-2" />
                Activate
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default AccessibilityPlus;