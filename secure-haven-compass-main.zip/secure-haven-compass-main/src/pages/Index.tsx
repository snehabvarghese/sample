import { Link } from "react-router-dom";
import { Shield, Accessibility, Users, GraduationCap, ArrowRight, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import Navigation from "@/components/Navigation";
import heroImage from "@/assets/hero-safety.jpg";

const Index = () => {
  const safetyModules = [
    {
      title: "Accessibility+",
      description: "Safety tools designed for people with disabilities, including accessibility heatmaps, building ratings, and specialized emergency support.",
      href: "/accessibility",
      icon: Accessibility,
      features: ["Unsafe zone visualization", "Building accessibility ratings", "Emergency SOS for disabilities"],
      gradient: "bg-gradient-primary"
    },
    {
      title: "SafeGuard+",
      description: "Comprehensive women's safety features with community support, AI escort tracking, and anonymous reporting systems.",
      href: "/safeguard",
      icon: Users,
      features: ["One-tap SOS", "EscortMe AI bot", "Women-only safety circles"],
      gradient: "bg-gradient-safety"
    },
    {
      title: "SafeCampus+",
      description: "Student safety platform addressing harassment, mental health, and campus security with peer support networks.",
      href: "/safecampus",
      icon: GraduationCap,
      features: ["Anonymous ragging reports", "SafeRoute tracking", "AI mental health check-ins"],
      gradient: "bg-accent"
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      {/* Hero Section */}
      <section className="relative py-20 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-hero opacity-90"></div>
        <div className="relative max-w-7xl mx-auto px-6 text-center">
          <div className="space-y-8">
            <div className="space-y-4">
              <div className="flex justify-center">
                <div className="bg-white/20 p-4 rounded-2xl backdrop-blur-sm">
                  <Shield className="h-16 w-16 text-white" />
                </div>
              </div>
              <h1 className="text-5xl md:text-7xl font-bold text-white">
                SafeConnect
              </h1>
              <p className="text-xl md:text-2xl text-white/90 max-w-3xl mx-auto">
                Comprehensive safety platform protecting vulnerable communities through AI-powered tools, community support, and real-time safety intelligence
              </p>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button variant="secondary" size="xl" asChild className="shadow-strong">
                <Link to="/accessibility">
                  <Accessibility className="h-6 w-6" />
                  Get Started
                </Link>
              </Button>
              <Button variant="outline" size="xl" className="bg-white/10 border-white/30 text-white hover:bg-white/20">
                Learn More
              </Button>
            </div>
          </div>
        </div>
        
        {/* Hero Image */}
        <div className="mt-16 max-w-5xl mx-auto px-6">
          <div className="relative">
            <img 
              src={heroImage} 
              alt="SafeConnect - Comprehensive safety platform for vulnerable communities"
              className="w-full h-96 object-cover rounded-2xl shadow-strong"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent rounded-2xl"></div>
            <div className="absolute bottom-6 left-6 text-white">
              <h3 className="text-xl font-bold">Protecting Communities Together</h3>
              <p className="text-white/90">AI-powered safety tools for everyone</p>
            </div>
          </div>
        </div>
      </section>

      {/* Safety Modules */}
      <section className="py-20 max-w-7xl mx-auto px-6">
        <div className="text-center space-y-4 mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-foreground">
            Three Specialized Safety Solutions
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Each platform is tailored to address the unique safety challenges faced by different vulnerable communities
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {safetyModules.map((module, index) => {
            const Icon = module.icon;
            return (
              <Card key={index} className="group hover:shadow-strong transition-all duration-300 transform hover:scale-105 overflow-hidden">
                <div className={`h-2 ${module.gradient}`}></div>
                <CardHeader className="space-y-4">
                  <div className={`w-16 h-16 ${module.gradient} rounded-2xl flex items-center justify-center`}>
                    <Icon className="h-8 w-8 text-white" />
                  </div>
                  <CardTitle className="text-2xl">{module.title}</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <p className="text-muted-foreground">
                    {module.description}
                  </p>
                  
                  <div className="space-y-3">
                    {module.features.map((feature, i) => (
                      <div key={i} className="flex items-center gap-3">
                        <CheckCircle className="h-5 w-5 text-success flex-shrink-0" />
                        <span className="text-sm">{feature}</span>
                      </div>
                    ))}
                  </div>
                  
                  <Button asChild className="w-full group-hover:shadow-medium">
                    <Link to={module.href}>
                      Explore {module.title}
                      <ArrowRight className="h-4 w-4" />
                    </Link>
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </section>

      {/* Statistics */}
      <section className="py-20 bg-muted/30">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center space-y-4 mb-16">
            <h2 className="text-4xl font-bold text-foreground">Making a Real Impact</h2>
            <p className="text-xl text-muted-foreground">
              Community-driven safety data helping protect vulnerable communities
            </p>
          </div>
          
          <div className="grid md:grid-cols-4 gap-8">
            <div className="text-center space-y-2">
              <div className="text-4xl font-bold text-primary">10,000+</div>
              <p className="text-muted-foreground">Safety Reports Submitted</p>
            </div>
            <div className="text-center space-y-2">
              <div className="text-4xl font-bold text-success">500+</div>
              <p className="text-muted-foreground">Buildings Rated</p>
            </div>
            <div className="text-center space-y-2">
              <div className="text-4xl font-bold text-accent">2,500+</div>
              <p className="text-muted-foreground">Active Community Members</p>
            </div>
            <div className="text-center space-y-2">
              <div className="text-4xl font-bold text-warning">50+</div>
              <p className="text-muted-foreground">Emergency Responses</p>
            </div>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-20">
        <div className="max-w-4xl mx-auto px-6 text-center space-y-8">
          <h2 className="text-4xl md:text-5xl font-bold text-foreground">
            Join the Safety Community
          </h2>
          <p className="text-xl text-muted-foreground">
            Together, we can create safer environments for everyone. Start with the platform that matches your needs.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button variant="hero" size="xl" asChild>
              <Link to="/accessibility">
                <Accessibility className="h-6 w-6" />
                Start with Accessibility+
              </Link>
            </Button>
            <Button variant="safety" size="xl" asChild>
              <Link to="/safeguard">
                <Users className="h-6 w-6" />
                Try SafeGuard+
              </Link>
            </Button>
            <Button variant="success" size="xl" asChild>
              <Link to="/safecampus">
                <GraduationCap className="h-6 w-6" />
                Explore SafeCampus+
              </Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Index;