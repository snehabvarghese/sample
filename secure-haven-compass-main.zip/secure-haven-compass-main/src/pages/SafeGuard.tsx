import { useState } from "react";
import { Shield, Phone, Users, MapPin, MessageSquare, AlertTriangle, UserCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import Navigation from "@/components/Navigation";
import heatmapImage from "@/assets/heatmap-visual.jpg";

const SafeGuard = () => {
  const [sosTriggered, setSosTriggered] = useState(false);
  const [isTracking, setIsTracking] = useState(false);
  const [showReportForm, setShowReportForm] = useState(false);

  const handleSOS = () => {
    setSosTriggered(true);
    setTimeout(() => setSosTriggered(false), 3000);
  };

  const handleEscortMe = () => {
    setIsTracking(!isTracking);
  };

  const safetyCircles = [
    {
      name: "Downtown Women's Circle",
      members: 342,
      activeNow: 28,
      location: "Downtown Area"
    },
    {
      name: "Campus Safety Network",
      members: 156,
      activeNow: 12,
      location: "University District"
    },
    {
      name: "Nightshift Workers Unite",
      members: 89,
      activeNow: 15,
      location: "Industrial Zone"
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <div className="max-w-7xl mx-auto p-6 space-y-8">
        {/* Header */}
        <div className="text-center space-y-4">
          <div className="flex justify-center">
            <div className="bg-gradient-primary p-4 rounded-2xl">
              <Shield className="h-12 w-12 text-primary-foreground" />
            </div>
          </div>
          <h1 className="text-4xl font-bold text-foreground">SafeGuard+</h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Comprehensive safety tools designed specifically for women's protection and community support
          </p>
        </div>

        {/* Quick Actions */}
        <div className="grid md:grid-cols-2 gap-6">
          {/* Emergency SOS */}
          <Card className={`shadow-strong ${sosTriggered ? 'bg-emergency/10 border-emergency' : ''}`}>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-emergency">
                <Phone className="h-6 w-6" />
                One-Tap SOS
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {sosTriggered ? (
                <div className="text-center space-y-4 animate-slide-up">
                  <div className="text-2xl font-bold text-emergency">🚨 Emergency Alert Active!</div>
                  <p className="text-lg">Emergency services, trusted contacts, and nearby safety circles have been alerted.</p>
                  <div className="bg-success/10 border border-success rounded-lg p-4">
                    <p className="text-success font-medium">✓ Location shared with authorities</p>
                    <p className="text-success font-medium">✓ Safety circles notified</p>
                    <p className="text-success font-medium">✓ Emergency contacts alerted</p>
                  </div>
                </div>
              ) : (
                <div className="text-center space-y-4">
                  <Button
                    variant="sos"
                    size="xl"
                    onClick={handleSOS}
                    className="w-full"
                  >
                    <AlertTriangle className="h-6 w-6" />
                    EMERGENCY SOS
                  </Button>
                  <p className="text-sm text-muted-foreground">
                    Instantly alerts authorities and your safety network
                  </p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* EscortMe AI Bot */}
          <Card className="shadow-medium">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-primary">
                <UserCheck className="h-6 w-6" />
                EscortMe AI
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-muted-foreground">
                AI-powered commute tracking that monitors your journey and alerts contacts if you deviate from your route
              </p>
              <Button 
                variant={isTracking ? "success" : "hero"} 
                size="lg" 
                onClick={handleEscortMe}
                className="w-full"
              >
                <MapPin className="h-5 w-5" />
                {isTracking ? "Stop Tracking" : "Start Safe Journey"}
              </Button>
              {isTracking && (
                <div className="bg-success/10 border border-success rounded-lg p-4 animate-slide-up">
                  <p className="text-success font-medium">✓ Journey tracking active</p>
                  <p className="text-sm text-success/80">AI monitoring your planned route</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {/* Safety Heatmap */}
          <Card className="shadow-medium">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MapPin className="h-5 w-5 text-primary" />
                Safety Heatmap
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="relative">
                <img 
                  src={heatmapImage} 
                  alt="Safety heatmap showing safe and unsafe zones for women"
                  className="w-full h-64 object-cover rounded-lg"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent rounded-lg" />
                <div className="absolute bottom-4 left-4 text-white">
                  <h3 className="font-bold">Crowdsourced Safety Data</h3>
                  <p className="text-sm opacity-90">Real-time reports from women in your area</p>
                </div>
              </div>
              <div className="flex justify-between text-sm">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-success rounded-full"></div>
                  <span>Safe Zone</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-warning rounded-full"></div>
                  <span>Caution</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-emergency rounded-full"></div>
                  <span>Avoid</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Anonymous Reporting */}
          <Card className="shadow-medium">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MessageSquare className="h-5 w-5 text-primary" />
                Anonymous Reporting
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {!showReportForm ? (
                <div className="text-center space-y-4">
                  <p className="text-muted-foreground">
                    Report harassment, unsafe areas, or suspicious activity anonymously to help other women stay safe
                  </p>
                  <Button 
                    variant="warning" 
                    onClick={() => setShowReportForm(true)}
                    className="w-full"
                  >
                    Submit Anonymous Report
                  </Button>
                </div>
              ) : (
                <div className="space-y-4 animate-slide-up">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Location</label>
                    <Input placeholder="Where did this incident occur?" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Incident Type</label>
                    <select className="w-full p-2 border border-border rounded-md bg-background">
                      <option>Harassment</option>
                      <option>Stalking</option>
                      <option>Unsafe Area</option>
                      <option>Poor Lighting</option>
                      <option>Other</option>
                    </select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Description</label>
                    <Textarea placeholder="Provide details to help other women stay safe..." rows={4} />
                  </div>
                  <div className="flex gap-2">
                    <Button variant="success" className="flex-1">Submit Report</Button>
                    <Button variant="outline" onClick={() => setShowReportForm(false)}>Cancel</Button>
                  </div>
                  <p className="text-xs text-muted-foreground">Your report is completely anonymous and helps build community safety data</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Safety Circles */}
        <Card className="shadow-medium">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5 text-primary" />
              Women's Safety Circles
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-muted-foreground">
              Join local women-only safety networks for peer support and community protection
            </p>
            <div className="grid md:grid-cols-3 gap-4">
              {safetyCircles.map((circle, index) => (
                <div key={index} className="border border-border rounded-lg p-4 space-y-3">
                  <h3 className="font-semibold text-foreground">{circle.name}</h3>
                  <p className="text-sm text-muted-foreground">{circle.location}</p>
                  <div className="space-y-1">
                    <div className="flex justify-between text-sm">
                      <span>Total Members</span>
                      <span className="font-medium">{circle.members}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Active Now</span>
                      <span className="font-medium text-success">{circle.activeNow}</span>
                    </div>
                  </div>
                  <Button variant="safety" size="sm" className="w-full">
                    Join Circle
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default SafeGuard;