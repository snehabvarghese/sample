import { useState } from "react";
import { GraduationCap, MessageCircle, Route, Users, Heart, Star, MapPin, Brain } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import Navigation from "@/components/Navigation";
import campusImage from "@/assets/campus-safety.jpg";

const SafeCampus = () => {
  const [showReportForm, setShowReportForm] = useState(false);
  const [showMentalHealthCheck, setShowMentalHealthCheck] = useState(false);
  const [trackingRoute, setTrackingRoute] = useState(false);

  const hostelRatings = [
    {
      name: "Sunrise Hostel",
      rating: 4.6,
      safety: "Excellent",
      features: ["24/7 Security", "CCTV", "Women's Floor", "Safe Lockers"],
      issues: [],
      price: "$80/month"
    },
    {
      name: "Campus View Residence",
      rating: 4.1,
      safety: "Good",
      features: ["Security Guard", "Visitor Log", "Well-lit"],
      issues: ["Old building", "Noisy area"],
      price: "$65/month"
    },
    {
      name: "Budget Stay",
      rating: 2.8,
      safety: "Poor",
      features: ["Basic amenities"],
      issues: ["No security", "Poor lighting", "Isolated location"],
      price: "$35/month"
    }
  ];

  const mentalHealthQuestions = [
    "How are you feeling today?",
    "Have you been sleeping well?",
    "Are you feeling overwhelmed with studies?",
    "Do you feel connected to your peers?"
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <div className="max-w-7xl mx-auto p-6 space-y-8">
        {/* Header */}
        <div className="text-center space-y-4">
          <div className="flex justify-center">
            <div className="bg-gradient-primary p-4 rounded-2xl">
              <GraduationCap className="h-12 w-12 text-primary-foreground" />
            </div>
          </div>
          <h1 className="text-4xl font-bold text-foreground">SafeCampus+</h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Comprehensive safety and wellness platform for students, addressing harassment, mental health, and campus security
          </p>
        </div>

        {/* Quick Actions */}
        <div className="grid md:grid-cols-3 gap-6">
          {/* Anonymous Reporting */}
          <Card className="shadow-medium">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-primary">
                <MessageCircle className="h-6 w-6" />
                Report Ragging
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-muted-foreground text-sm">
                Anonymously report bullying, ragging, or harassment incidents
              </p>
              <Button 
                variant="warning" 
                onClick={() => setShowReportForm(!showReportForm)}
                className="w-full"
              >
                Submit Anonymous Report
              </Button>
            </CardContent>
          </Card>

          {/* SafeRoute Tracker */}
          <Card className="shadow-medium">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-primary">
                <Route className="h-6 w-6" />
                SafeRoute Tracker
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-muted-foreground text-sm">
                Track your route from hostel to class with safety monitoring
              </p>
              <Button 
                variant={trackingRoute ? "success" : "hero"} 
                onClick={() => setTrackingRoute(!trackingRoute)}
                className="w-full"
              >
                <MapPin className="h-4 w-4" />
                {trackingRoute ? "Stop Tracking" : "Start Route"}
              </Button>
            </CardContent>
          </Card>

          {/* Mental Health Check-in */}
          <Card className="shadow-medium">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-primary">
                <Brain className="h-6 w-6" />
                Mental Health AI
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-muted-foreground text-sm">
                AI-powered mental health check-ins and support
              </p>
              <Button 
                variant="safety" 
                onClick={() => setShowMentalHealthCheck(!showMentalHealthCheck)}
                className="w-full"
              >
                <Heart className="h-4 w-4" />
                Check-in Now
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Expandable Forms */}
        {showReportForm && (
          <Card className="shadow-strong border-warning animate-slide-up">
            <CardHeader>
              <CardTitle className="text-warning">Anonymous Incident Report</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Incident Type</label>
                  <select className="w-full p-2 border border-border rounded-md bg-background">
                    <option>Ragging/Bullying</option>
                    <option>Sexual Harassment</option>
                    <option>Discrimination</option>
                    <option>Theft</option>
                    <option>Safety Concern</option>
                    <option>Other</option>
                  </select>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Location</label>
                  <Input placeholder="Where did this occur? (Building, room, area)" />
                </div>
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium">Description</label>
                <Textarea 
                  placeholder="Please provide details about the incident. Your report helps create a safer campus for everyone."
                  rows={4}
                />
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium">Severity Level</label>
                <select className="w-full p-2 border border-border rounded-md bg-background">
                  <option>Low - Uncomfortable situation</option>
                  <option>Medium - Concerning behavior</option>
                  <option>High - Serious incident</option>
                  <option>Critical - Immediate danger</option>
                </select>
              </div>

              <div className="flex gap-2">
                <Button variant="warning" className="flex-1">Submit Report</Button>
                <Button variant="outline" onClick={() => setShowReportForm(false)}>Cancel</Button>
              </div>
              <p className="text-xs text-muted-foreground">
                All reports are completely anonymous. Serious incidents will be forwarded to campus security and administration.
              </p>
            </CardContent>
          </Card>
        )}

        {showMentalHealthCheck && (
          <Card className="shadow-strong border-success animate-slide-up">
            <CardHeader>
              <CardTitle className="text-success flex items-center gap-2">
                <Heart className="h-5 w-5" />
                AI Mental Health Check-in
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-muted-foreground">
                Let's check in on how you're doing today. Your responses help our AI provide personalized support.
              </p>
              
              {mentalHealthQuestions.map((question, index) => (
                <div key={index} className="space-y-2">
                  <label className="text-sm font-medium">{question}</label>
                  <div className="flex gap-2">
                    {['😊', '😐', '😟', '😢'].map((emoji, i) => (
                      <button
                        key={i}
                        className="text-2xl p-2 rounded-lg border border-border hover:bg-muted transition-colors"
                      >
                        {emoji}
                      </button>
                    ))}
                  </div>
                </div>
              ))}
              
              <div className="space-y-2">
                <label className="text-sm font-medium">Any additional thoughts or concerns?</label>
                <Textarea placeholder="Optional: Share anything else on your mind..." rows={3} />
              </div>

              <div className="flex gap-2">
                <Button variant="success" className="flex-1">Complete Check-in</Button>
                <Button variant="outline" onClick={() => setShowMentalHealthCheck(false)}>Skip</Button>
              </div>
              <p className="text-xs text-muted-foreground">
                Based on your responses, we'll provide personalized wellness tips and connect you with resources if needed.
              </p>
            </CardContent>
          </Card>
        )}

        <div className="grid md:grid-cols-2 gap-8">
          {/* Campus Safety Features */}
          <Card className="shadow-medium">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Route className="h-5 w-5 text-primary" />
                Campus Safety Features
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="relative">
                <img 
                  src={campusImage} 
                  alt="Safe campus routes and student safety features"
                  className="w-full h-64 object-cover rounded-lg"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent rounded-lg" />
                <div className="absolute bottom-4 left-4 text-white">
                  <h3 className="font-bold">Safe Campus Navigation</h3>
                  <p className="text-sm opacity-90">Optimized routes between hostel and classes</p>
                </div>
              </div>
              
              <div className="space-y-3">
                <div className="flex items-center gap-3 p-3 border border-border rounded-lg">
                  <div className="w-2 h-2 bg-success rounded-full animate-pulse"></div>
                  <span className="text-sm">Well-lit pathways prioritized</span>
                </div>
                <div className="flex items-center gap-3 p-3 border border-border rounded-lg">
                  <div className="w-2 h-2 bg-success rounded-full animate-pulse"></div>
                  <span className="text-sm">Security camera coverage mapped</span>
                </div>
                <div className="flex items-center gap-3 p-3 border border-border rounded-lg">
                  <div className="w-2 h-2 bg-success rounded-full animate-pulse"></div>
                  <span className="text-sm">Emergency call boxes located</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Peer Support Network */}
          <Card className="shadow-medium">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5 text-primary" />
                Peer Whistleblower Support
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-muted-foreground">
                Connect with verified student volunteers who can provide support and guidance
              </p>
              
              <div className="space-y-3">
                <div className="flex items-center justify-between p-3 border border-border rounded-lg">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-gradient-primary rounded-full flex items-center justify-center">
                      <span className="text-primary-foreground font-bold">A</span>
                    </div>
                    <div>
                      <p className="font-medium">Anonymous Student A</p>
                      <p className="text-xs text-success">Available now</p>
                    </div>
                  </div>
                  <Button size="sm" variant="success">Connect</Button>
                </div>
                
                <div className="flex items-center justify-between p-3 border border-border rounded-lg">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-gradient-safety rounded-full flex items-center justify-center">
                      <span className="text-success-foreground font-bold">B</span>
                    </div>
                    <div>
                      <p className="font-medium">Anonymous Student B</p>
                      <p className="text-xs text-success">Available now</p>
                    </div>
                  </div>
                  <Button size="sm" variant="success">Connect</Button>
                </div>
                
                <div className="flex items-center justify-between p-3 border border-border rounded-lg opacity-60">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-muted rounded-full flex items-center justify-center">
                      <span className="text-muted-foreground font-bold">C</span>
                    </div>
                    <div>
                      <p className="font-medium">Anonymous Student C</p>
                      <p className="text-xs text-muted-foreground">Away</p>
                    </div>
                  </div>
                  <Button size="sm" variant="outline" disabled>Offline</Button>
                </div>
              </div>
              
              <p className="text-xs text-muted-foreground">
                All peer supporters are verified students trained in confidential support and crisis intervention.
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Hostel Safety Ratings */}
        <Card className="shadow-medium">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Star className="h-5 w-5 text-primary" />
              Hostel Safety Ratings
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-muted-foreground">
              Make informed decisions about accommodation with community-verified safety ratings
            </p>
            
            <div className="grid md:grid-cols-3 gap-6">
              {hostelRatings.map((hostel, index) => (
                <div key={index} className="border border-border rounded-lg p-4 space-y-4">
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="font-semibold text-foreground">{hostel.name}</h3>
                      <p className="text-lg font-bold text-primary">{hostel.price}</p>
                    </div>
                    <div className="text-right">
                      <div className="flex items-center gap-1">
                        <Star className="h-4 w-4 fill-warning text-warning" />
                        <span className="font-bold">{hostel.rating}</span>
                      </div>
                      <Badge 
                        variant={hostel.safety === "Excellent" ? "default" : 
                               hostel.safety === "Good" ? "secondary" : "destructive"}
                        className="text-xs"
                      >
                        {hostel.safety}
                      </Badge>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <p className="text-sm font-medium text-success">Safety Features:</p>
                    <div className="flex flex-wrap gap-1">
                      {hostel.features.map((feature, i) => (
                        <Badge key={i} variant="outline" className="text-xs">
                          {feature}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  
                  {hostel.issues.length > 0 && (
                    <div className="space-y-2">
                      <p className="text-sm font-medium text-warning">Reported Issues:</p>
                      {hostel.issues.map((issue, i) => (
                        <p key={i} className="text-xs text-muted-foreground">• {issue}</p>
                      ))}
                    </div>
                  )}
                  
                  <Button variant="outline" size="sm" className="w-full">
                    View Details
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default SafeCampus;